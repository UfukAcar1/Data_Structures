public class End extends Pipe{
    public End(String way){
        super(way.equals("Vertical") ? "down" : "left", null, false, way.equals("Horizontal") ? "EndHorizontal.png" : "EndVertical.png");
        end = true;
    }
}
