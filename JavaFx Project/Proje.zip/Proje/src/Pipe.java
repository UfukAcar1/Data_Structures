public class Pipe {
    public String firstWay, secondWay, tileLink;
    public boolean movable, starter = false, end = false, firstWayAccessed = false, secondWayAccessed = false, occupied = true;
    public Pipe(String firstWay, String secondWay, boolean movable, String tileLink){
        this.firstWay = firstWay;
        this.secondWay = secondWay;
        this.movable = movable;
        this.tileLink = tileLink;
    }

    //We defined properties of pipes
    public Pipe(String s){
        movable = true;
        if(s.length() == 2) {
            switch (s) {
                case "00":
                    firstWay = "left";
                    secondWay = "up";
                    tileLink = "00.png";
                    break;
                case "01":
                    firstWay = "right";
                    secondWay = "up";
                    tileLink = "01.png";
                    break;
                case "10":
                    firstWay = "left";
                    secondWay = "down";
                    tileLink = "10.png";
                    break;
                case "11":
                    firstWay = "right";
                    secondWay = "down";
                    tileLink = "11.png";
            }
        }
        else{
            if(s.equals("Vertical")){
                firstWay = "up";
                secondWay = "down";
                tileLink = "PipeVertical.png";
            }
            else{
                firstWay = "left";
                secondWay = "right";
                tileLink = "PipeHorizontal.png";
            }
        }
    }
}
