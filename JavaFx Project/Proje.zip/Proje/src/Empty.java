public class Empty extends Pipe {
    public Empty(String s){
        super(null, null, true, s.equals("Free") ? "EmptyFree.png" : "Empty.png");
        if(s.equals("Free"))
            this.occupied = false;
    }
}
