public class Triangle {
    public static  void main(String[] args) {
        for (int row=1; row<10; row += 2){
            for (int column=0; column < (4 - row / 2); column++){
                System.out.print("_");
            }
            for (int j=0; j<row; j++){
                System.out.print("1");
            }
            System.out.println("_");
        }
    }
}
