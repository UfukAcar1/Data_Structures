public class PipeStatic extends Pipe{
    public PipeStatic(String way){
        super( way.length()==2 ? (way.equals("00") || way.equals("01") ? "up" : ("down")) : (way.equals("Vertical") ? "down": "right"), way.length() == 2 ? (way.equals("00") || way.equals("10")  ? "left" :"right") : (way.equals("Vertical") ? "up" : "left"), false, way.equals("00") ? "PipeStatic00.png" : (way.equals("01") ? "PipeStatic01.png" : (way.equals("10") ? "PipeStatic10.png" : (way.equals("11") ? "PipeStatic11.png" : (way.equals("Vertical") ? "PipeStaticVertical.png" : "PipeStaticHorizontal.png")))));
    }
}
