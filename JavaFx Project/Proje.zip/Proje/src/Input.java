/*
import java.io.File;
import java.util.Objects;
import java.util.Scanner;

public class Input {
    public static void main(String[] Args){
        String[][] stringCell = new String[4][4];
        String[][] stringCell2 = new String[4][4];
        try{
            int n = 1;
            while(true){
                //Users/nilsu/IdeaProjects/fx/src/CSE1242_spring2022_project_level   /Users/ufukacar/IdeaProjects/Proje
                Scanner input = new Scanner(new File("/Users/ufukacar/IdeaProjects/Proje/src/CSE1242_spring2022_project_level"+n+".txt"));
                while(input.hasNext()) {
                    String[] splitted = (input.nextLine()).split(",");
                    if(!Objects.equals(splitted[0], "")){
                        int x = Integer.parseInt(splitted[0]);
                        stringCell[(x-1)/4][(x-1)%4] = splitted[1];
                        stringCell2[(x-1)/4][(x-1)%4] = splitted[2];
                    }
                }
                System.out.println(stringCell[0][0]);
                n += 1;
            }
        } catch(Exception ex){
        }
    }
}
*/