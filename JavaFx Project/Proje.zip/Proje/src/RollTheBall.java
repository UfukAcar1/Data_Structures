//Ufuk Acar 150121071 - Ege Keklikçi 150121029
import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polyline;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Objects;
import java.util.Scanner;


public class RollTheBall extends Application {
    int currentY, currentX, level = 2, starterY, starterX;
    private Cell[][] cell = new Cell[4][4];
    Pipe[][] pipeArray = new Pipe[4][4];
    private Label levelLabel = new Label("Level 1");
    ImageView[][] imageViewArray = new ImageView[4][4];
    GridPane pane = new GridPane();
    String[][] pipeNames = new String[4][4], pipeProperties = new String[4][4];
    BorderPane borderPane = new BorderPane();
    Button nextLevel = new Button("Next Level");
    Button tryAgain = new Button("Try Again");
    Label finished = new Label();
    String pathY, pathX;

    @Override
    public void start(Stage primaryStage) throws Exception {
        tryAgain.setVisible(false);
        nextLevel.setOnAction((event) -> {
            try {
                startAgain();
            } catch (Exception e) {
                finished.setText("All levels are finished\n    Highest Score "+(level-1));
                finished.setFont(new Font("Arial", 30));
                borderPane.setCenter(finished);
                borderPane.setBottom(tryAgain);
                borderPane.setAlignment(tryAgain, Pos.CENTER);

                nextLevel.setVisible(false);
                tryAgain.setVisible(true);
            }
        });
        tryAgain.setOnAction(event -> {
            level = 1;
            try {
                startAgain();
            } catch (Exception e) {
            }
        });
        //read input from the file
        Scanner input = new Scanner(new File("/Users/ufukacar/IdeaProjects/Proje/src/CSE1242_spring2022_project_level1.txt"));
        while(input.hasNext()){
            String[] splitted = (input.nextLine()).split(",");
            if(!Objects.equals(splitted[0], "")){
                int x = Integer.parseInt(splitted[0]);
                pipeNames[(x-1)/4][(x-1)%4] = splitted[1];
                pipeProperties[(x-1)/4][(x-1)%4] = splitted[2];
            }
        }
        //create cell and pipe for each grid pane
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++) {
                //add new cell
                pane.add(cell[i][j] = new Cell(), j, i);
                //find which pipe will be added according to the input
                Pipe pipe = pipeFinder(pipeNames[i][j], pipeProperties[i][j]);
                //add pipe to the array
                pipeArray[i][j] = pipe;
                //create an image view according to the tile
                ImageView tilePhoto = new ImageView(pipe.tileLink);
                //bind width and height property, because of this if window size is changed the tiles changes with it
                tilePhoto.maxWidth(128);
                tilePhoto.maxHeight(128);
                tilePhoto.fitHeightProperty().bind(cell[i][j].heightProperty());
                tilePhoto.fitWidthProperty().bind(cell[i][j].widthProperty());
                // declare finalI and finalJ variables because released() method cannot work with i and j
                int finalI = i;
                int finalJ = j;
                //add image view mouse released event
                tilePhoto.setOnMouseReleased(event -> released(event, finalI, finalJ, cell[finalI][finalJ].getWidth(), cell[finalI][finalJ].getHeight(), pane));
                //add image view to the array
                imageViewArray[i][j] = tilePhoto;
                //imageViewArray[i][j].setPreserveRatio(true);
                //add image view to the pane
                pane.add(tilePhoto, j, i);
                //center the image view inside the grid pane
                pane.setHalignment(tilePhoto, HPos.CENTER);
                //determine which cell is starter
                if(pipeArray[i][j].starter){
                    currentY = i ;
                    starterY = i;
                    currentX = j ;
                    starterX = j;
                }
            }
        //add label to our border pane in the bottom
        levelLabel.setFont(new Font("Arial",30));
        borderPane.setBottom(levelLabel);
        //center the bottom
        borderPane.setAlignment(levelLabel, Pos.CENTER);
        borderPane.setTop(nextLevel);
        nextLevel.setVisible(false);
        borderPane.setAlignment(nextLevel, Pos.CENTER);
        //set max pane size
        pane.setMaxSize(cell[0][0].getWidth()*4, cell[0][0].getHeight()*4);
        //add the ball
        Circle circle = new Circle(22);
        circle.setCenterX((starterX +0.5)*125);
        circle.setCenterY((starterY +0.5)*125);
        //create a group with pane and circle
        Group group = new Group(circle, pane);
        //circle needs to be in the front to be seen
        circle.toFront();
        //add group to border pane's center
        borderPane.setCenter(group);
        // Create a scene and place it in the stage
        Scene scene = new Scene(borderPane, 500, 600);
        primaryStage.setTitle("Board Game"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.sizeToScene();
        primaryStage.setResizable(false);
        primaryStage.show(); // Display the stage
        //check if the user won
        if(isWon()){
            animation();
            //next level button can be seen now
            nextLevel.setVisible(true);
            //label is updated to level completed
            levelLabel.setText("LEVEL COMPLETED!");
            //lock the tiles, the user cannot move after winning
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    pipeArray[i][j].movable = false;
        }
    }
    //this will detect if the mouse is clicked and released
    private void released(MouseEvent event, int i, int j, double cellWidth, double cellHeight, GridPane pane) {
        //get mouse's x and y location
        int x = (int) (event.getSceneX()/cellWidth), y = (int) (event.getSceneY()/cellHeight);
        //check if the selected to tiles are neighbours, they are not outside the window, and they are movable, and not occupied if so change the 2 tiles
        if(i < 4 && j < 4 && y < 4 && x < 4 && pipeArray[i][j].movable && pipeArray[y][x].movable && ((((i - y) == -1 || (i - y) == 1) && (j - x) == 0) || ((((j - x) == -1 || (j - x) == 1) && (i - y) == 0))) && (!pipeArray[i][j].occupied || !pipeArray[y][x].occupied)) {
            //remove the image view from the array
            pane.getChildren().remove(imageViewArray[i][j]);
            pane.getChildren().remove(imageViewArray[y][x]);
            //find and add the new image view according to new locations image
            imageViewArray[i][j] = new ImageView(pipeArray[y][x].tileLink);
            imageViewArray[y][x] = new ImageView(pipeArray[i][j].tileLink);
            //bind the x and y values
            imageViewArray[i][j].fitHeightProperty().bind(cell[i][j].heightProperty());
            imageViewArray[i][j].fitWidthProperty().bind(cell[i][j].widthProperty());
            imageViewArray[y][x].fitHeightProperty().bind(cell[y][x].heightProperty());
            imageViewArray[y][x].fitWidthProperty().bind(cell[y][x].widthProperty());
            //set the mouse properties
            imageViewArray[i][j].setOnMouseReleased(Event -> released(Event, i, j, cell[i][j].getWidth(), cell[i][j].getHeight(), pane));
            imageViewArray[y][x].setOnMouseReleased(Event -> released(Event, y, x, cell[y][x].getWidth(), cell[y][x].getHeight(), pane));
            //change the location in the pipeArray
            Pipe tempPipe = pipeArray[i][j];
            pipeArray[i][j] = pipeArray[y][x];
            pipeArray[y][x] = tempPipe;

            //add the image views to the grid pane
            pane.add(imageViewArray[i][j], j, i);
            pane.add(imageViewArray[y][x], x, y);
            pane.setHalignment(imageViewArray[i][j], HPos.CENTER);
            pane.setHalignment(imageViewArray[y][x], HPos.CENTER);

            //clear the accessed value for all, this is for the isWon method
            for(int a = 0; a < 4; a++){
                for(int b = 0; b < 4; b++){
                    pipeArray[a][b].firstWayAccessed = false;
                    pipeArray[a][b].secondWayAccessed = false;
                }
            }
            //check if the user won
            if(isWon()){
                //animate
                animation();
                //next level button can be seen now
                nextLevel.setVisible(true);
                //label is updated to level completed
                levelLabel.setText("LEVEL COMPLETED!");
                //lock the tiles, the user cannot move after winning
                for (int a = 0; a < 4; a++)
                    for (int b = 0; b < 4; b++)
                        pipeArray[a][b].movable = false;
            }
        }
    }

    public class Cell extends Pane {
        public Cell(){
            setStyle("-fx-border-color: black");
            this.setPrefSize(800, 800);
        }
    }

    //check if the user won
    public boolean isWon(){
        int i = currentY, j = currentX;
        //this if will find if the first tile is connected to another tile with the appropriate way
        if(i < 4 && 0 <= i && j < 4 && 0 <= j) {
            if (pipeArray[i][j].secondWay.equals("down")) {
                if (pipeArray[i+1][j].secondWay != null && pipeArray[i+1][j].firstWay != null) {
                    if (pipeArray[i + 1][j].firstWay.equals("up")) {
                        pipeArray[i + 1][j].firstWayAccessed = true;
                        pathY += currentY; pathX += currentX;
                        currentY += 1;
                    } else if (pipeArray[i + 1][j].secondWay.equals("up")) {
                        pipeArray[i + 1][j].secondWayAccessed = true;
                        pathY += currentY; pathX += currentX;
                        currentY += 1;
                    } else {
                        return false;
                    }
                }
            }
            else if (pipeArray[i][j].secondWay.equals("left")) {
                if (pipeArray[i][j-1].secondWay != null && pipeArray[i][j-1].firstWay != null) {
                    if (pipeArray[i][j - 1].firstWay.equals("right")) {
                        pathY += currentY; pathX += currentX;
                        pipeArray[i][j - 1].firstWayAccessed = true;
                        currentX -= 1;
                    } else if (pipeArray[i][j - 1].secondWay.equals("right")) {
                        pipeArray[i][j - 1].secondWayAccessed = true;
                        pathY += currentY; pathX += currentX;
                        currentX -= 1;
                    } else {
                        return false;
                    }
                }
            }
        }
        else{
            return false;
        }
        //this will check if the tile are connected to start to end in the correct order
        boolean ended = true;
        while(ended){
            if(pipeArray[currentY][currentX].end){
                pathY += currentY;
                pathX += currentX;
                return true;
            }
            else {
                pathY += currentY;
                pathX += currentX;
                ended = find(currentY, currentX);
            }
        }
        pathY =""; pathX ="";
        currentY = i; currentX = j;
        return pipeArray[currentY][currentX].end;
    }
    //this method will find if tile is connected to another tile with the appropriate way
    public boolean find(int i, int j){
        if(pipeArray[i][j].firstWayAccessed && !pipeArray[i][j].secondWayAccessed){
            switch (pipeArray[i][j].secondWay){
                case "down":
                    if(i<3){
                        if(pipeArray[i+1][j].firstWay != null && pipeArray[i+1][j].firstWay.equals("up")){
                            pipeArray[i][j].secondWayAccessed = true;
                            pipeArray[i+1][j].firstWayAccessed = true;
                            currentY += 1;
                        }
                        else if(pipeArray[i+1][j].secondWay != null && pipeArray[i+1][j].secondWay.equals("up")){
                            pipeArray[i][j].secondWayAccessed = true;
                            pipeArray[i+1][j].secondWayAccessed = true;
                            currentY += 1;
                        }
                        else{
                            return false;
                        }
                        return true;
                    }
                case "up":
                    if(0<i){
                        if(pipeArray[i-1][j].firstWay != null && pipeArray[i-1][j].firstWay.equals("down")){
                            pipeArray[i][j].secondWayAccessed = true;
                            pipeArray[i-1][j].firstWayAccessed = true;
                            currentY -= 1;
                        }
                        else if(pipeArray[i-1][j].secondWay != null && pipeArray[i-1][j].secondWay.equals("down")){
                            pipeArray[i][j].secondWayAccessed = true;
                            pipeArray[i-1][j].secondWayAccessed = true;
                            currentY -= 1;
                        }
                        else{
                            return false;
                        }
                        return true;
                    }
                case "left":
                    if(0<j){
                        if(pipeArray[i][j-1].firstWay != null && pipeArray[i][j-1].firstWay.equals("right")){
                            pipeArray[i][j].secondWayAccessed = true;
                            pipeArray[i][j-1].firstWayAccessed = true;
                            currentX -= 1;
                        }
                        else if(pipeArray[i][j-1].secondWay != null && pipeArray[i][j-1].secondWay.equals("right")){
                            pipeArray[i][j].secondWayAccessed = true;
                            pipeArray[i][j-1].secondWayAccessed = true;
                            currentX -= 1;
                        }
                        else{
                            return false;
                        }
                        return true;
                    }
                case "right":
                    if(j<3){
                        if(pipeArray[i][j+1].firstWay != null && pipeArray[i][j+1].firstWay.equals("left")){
                            pipeArray[i][j].secondWayAccessed = true;
                            pipeArray[i][j+1].firstWayAccessed = true;
                            currentX += 1;
                        }
                        else if(pipeArray[i][j+1].secondWay != null && pipeArray[i][j+1].secondWay.equals("left")){
                            pipeArray[i][j].secondWayAccessed = true;
                            pipeArray[i][j+1].secondWayAccessed = true;
                            currentX += 1;
                        }
                        else{
                            return false;
                        }
                        return true;
                    }
            }
        }
        else if(pipeArray[i][j].secondWayAccessed && !pipeArray[i][j].firstWayAccessed){
            switch (pipeArray[i][j].firstWay){
                case "down":
                    if(i<3){
                        if(pipeArray[i+1][j].firstWay != null && pipeArray[i+1][j].firstWay.equals("up")){
                            pipeArray[i][j].firstWayAccessed = true;
                            pipeArray[i+1][j].firstWayAccessed = true;
                            currentY += 1;
                        }
                        else if(pipeArray[i+1][j].secondWay != null && pipeArray[i+1][j].secondWay.equals("up")){
                            pipeArray[i][j].firstWayAccessed = true;
                            pipeArray[i+1][j].secondWayAccessed = true;
                            currentY += 1;
                        }
                        else{
                            return false;
                        }
                        return true;
                    }
                case "up":
                    if(0<i){
                        if(pipeArray[i-1][j].firstWay != null && pipeArray[i-1][j].firstWay.equals("down")){
                            pipeArray[i][j].firstWayAccessed = true;
                            pipeArray[i-1][j].firstWayAccessed = true;
                            currentY -= 1;
                        }
                        else if(pipeArray[i-1][j].secondWay != null && pipeArray[i-1][j].secondWay.equals("down")){
                            pipeArray[i][j].firstWayAccessed = true;
                            pipeArray[i-1][j].secondWayAccessed = true;
                            currentY -= 1;
                        }
                        else{
                            return false;
                        }
                        return true;
                    }
                case "left":
                    if(0<j){
                        if(pipeArray[i][j-1].firstWay != null && pipeArray[i][j-1].firstWay.equals("right")){
                            pipeArray[i][j].firstWayAccessed = true;
                            pipeArray[i][j-1].firstWayAccessed = true;
                            currentX -= 1;
                        }
                        else if(pipeArray[i][j-1].secondWay != null && pipeArray[i][j-1].secondWay.equals("right")){
                            pipeArray[i][j].firstWayAccessed = true;
                            pipeArray[i][j-1].secondWayAccessed = true;
                            currentX -= 1;
                        }
                        else{
                            return false;
                        }
                        return true;
                    }
                case "right":
                    if(j<3){
                        if(pipeArray[i][j+1].firstWay != null && pipeArray[i][j+1].firstWay.equals("left")){
                            pipeArray[i][j].firstWayAccessed = true;
                            pipeArray[i][j+1].firstWayAccessed = true;
                            currentX += 1;
                        }
                        else if(pipeArray[i][j+1].secondWay != null && pipeArray[i][j+1].secondWay.equals("left")){
                            pipeArray[i][j].firstWayAccessed = true;
                            pipeArray[i][j+1].secondWayAccessed = true;
                            currentX += 1;
                        }
                        else{
                            return false;
                        }
                        return true;
                    }
            }
        }
        return false;
    }
    public static Pipe pipeFinder(String pipe, String property){
        switch (pipe){
            case "Starter":
                return new Starter(property);
            case "Empty":
                return new Empty(property);
            case "PipeStatic":
                return new PipeStatic(property);
            case "End":
                return new End(property);
            default:
                return new Pipe(property);
        }
    }
    public void startAgain() throws FileNotFoundException {
        levelLabel.setText("Level "+level);
        borderPane.getChildren().remove(pane);
        pane.getChildren().removeAll();
        //read input from the file
        Scanner input = new Scanner(new File("/Users/ufukacar/IdeaProjects/Proje/src/CSE1242_spring2022_project_level"+level+".txt"));
        while(input.hasNext()){
            String[] splitted = (input.nextLine()).split(",");
            if(!Objects.equals(splitted[0], "")){
                int x = Integer.parseInt(splitted[0]);
                pipeNames[(x-1)/4][(x-1)%4] = splitted[1];
                pipeProperties[(x-1)/4][(x-1)%4] = splitted[2];
            }
        }
        //create cell and pipe for each grid pane
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 4; j++) {
                //add new cell
                pane.add(cell[i][j] = new Cell(), j, i);
                //find which pipe will be added according to the input
                Pipe pipe = pipeFinder(pipeNames[i][j], pipeProperties[i][j]);
                //add pipe to the array
                pipeArray[i][j] = pipe;
                //create an image view according to the tile
                ImageView tilePhoto = new ImageView(pipe.tileLink);
                //bind width and height property, because of this if window size is changed the tiles changes with it
                tilePhoto.fitHeightProperty().bind(cell[i][j].heightProperty());
                tilePhoto.fitWidthProperty().bind(cell[i][j].widthProperty());
                // declare finalI and finalJ variables because released() method cannot work with i and j
                int finalI = i;
                int finalJ = j;
                //add image view mouse released event
                tilePhoto.setOnMouseReleased(event -> released(event, finalI, finalJ, cell[finalI][finalJ].getWidth(), cell[finalI][finalJ].getHeight(), pane));
                //add image view to the array
                imageViewArray[i][j] = tilePhoto;
                //add image view to the pane
                pane.add(tilePhoto, j, i);
                //center the image view inside the grid pane
                pane.setHalignment(tilePhoto, HPos.CENTER);
                //determine which cell is starter
                if(pipeArray[i][j].starter){
                    currentY = i; currentX = j; starterY = i; starterX = j;
                }
            }
        //add grid pane to our border pane in the center
        borderPane.setBottom(levelLabel);
        Circle c = new Circle(22);
        double centerX = (starterX +0.5)*125;
        double centerY = (starterY +0.5)*125;
        c.setCenterX(centerX);
        c.setCenterY(centerY);
        Group group = new Group(c, pane);
        c.toFront();
        borderPane.setCenter(group);
        nextLevel.setVisible(false);
        level += 1;
    }

    public static void Main(String[] args){
        launch(args);
    }

    //animate the ball from start to end
    public void animation(){
        System.out.println(pathY);
        // add a new circle with radius 22
        Circle circle = new Circle(22);
        // add a new pane group with pane and our circle
        Group group = new Group(circle, pane);
        //circle needs to be in front of the grid pane in order to be seen
        circle.toFront();
        //add group to border pane's center
        borderPane.setCenter(group);
        //add points according to our path
        Double[] points = new Double[pathY.length()*2];
        for(int i = 0; i < pathY.length()*2; i++){
            if(i%2==0){
                points[i] = (Integer.parseInt(""+ pathX.charAt(i/2))+0.5)*125;
            }
            else{
                points[i] = (Integer.parseInt(""+ pathY.charAt(i/2))+0.5)*125 + 8;
            }
        }
        Polyline poly = new Polyline();
        poly.getPoints().addAll(points);
        PathTransition transition = new PathTransition();
        transition.setDuration(Duration.millis(1000));
        transition.setNode(circle);
        transition.setPath(poly);
        transition.play();
        pathY = "";
        pathX = "";
    }
}
