public class Starter extends Pipe {
    public Starter(String way){
        //LEFT/right?
        super(null, way.equals("Vertical") ? "down" : "left", false, way.equals("Vertical") ? "StartVertical.png" : "StartHorizontal.png");
        starter = true;
    }
}
